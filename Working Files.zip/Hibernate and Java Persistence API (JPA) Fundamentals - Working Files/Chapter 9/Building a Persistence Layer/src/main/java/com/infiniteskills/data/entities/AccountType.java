package com.infiniteskills.data.entities;

public enum AccountType {
	LOAN,
	SAVINGS,
	CHECKING
}
